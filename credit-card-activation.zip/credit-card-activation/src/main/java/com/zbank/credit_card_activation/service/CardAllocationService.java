package com.zbank.credit_card_activation.service;

import java.time.LocalDateTime;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zbank.credit_card_activation.model.CardDetails;
import com.zbank.credit_card_activation.model.CreditScore;
import com.zbank.credit_card_activation.repository.CardDetailsRepository;
import com.zbank.credit_card_activation.repository.CreditScoreRepository;

@Service
public class CardAllocationService {

    @Autowired
    private CreditScoreRepository creditScoreRepository;

    @Autowired
    private CardDetailsRepository cardDetailsRepository;

    public CardDetails allocateCard(String userId) {
        CreditScore creditScore = creditScoreRepository.findByUserId(userId);

        if (creditScore == null) {
            throw new RuntimeException("User with given ID not found");
        }

        String cardType;
        int creditLimit;
        if (creditScore.getCreditscore() >= 500) {
            cardType = "PLATINUM";
            creditLimit = 40000;
        } else if (creditScore.getCreditscore() >= 300) {
            cardType = "GOLD";
            creditLimit = 20000;
        } else if (creditScore.getCreditscore() >= 150) {
            cardType = "VISA";
            creditLimit = 10000;
        } else {
            throw new RuntimeException("Additional documents required for low credit score");
        }

        CardDetails cardDetails = new CardDetails();
        cardDetails.setCardId(UUID.randomUUID().toString());
        cardDetails.setUserId(userId);
        cardDetails.setCardType(cardType);
        cardDetails.setCreditLimit(creditLimit);
        cardDetails.setCardNumber((long) (Math.random() * 1_000_000_000_000L));
        cardDetails.setPin(UUID.randomUUID().toString().substring(0, 4));
        cardDetails.setIssueDate(LocalDateTime.now());

        return cardDetailsRepository.save(cardDetails);
    }
}

