package com.zbank.credit_card_activation.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CreditScore")
public class CreditScore {
    @Id
    private String creditscoreId;
    private int creditscore;
    private String userId;

    // Getters and Setters
    public String getCreditscoreId() {
        return creditscoreId;
    }

    public void setCreditscoreId(String creditscoreId) {
        this.creditscoreId = creditscoreId;
    }

    public int getCreditscore() {
        return creditscore;
    }

    public void setCreditscore(int creditscore) {
        this.creditscore = creditscore;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}

