package com.zbank.credit_card_activation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.zbank.credit_card_activation.model.CardDetails;
import com.zbank.credit_card_activation.service.CardAllocationService;

@RestController
@RequestMapping("/api/card")
public class CardController {

    @Autowired
    private CardAllocationService cardAllocationService;

    @PostMapping("/allocate/{userId}")
    public ResponseEntity<CardDetails> allocateCard(@PathVariable String userId) {
        CardDetails cardDetails = cardAllocationService.allocateCard(userId);
        return ResponseEntity.ok(cardDetails);
    }
}

