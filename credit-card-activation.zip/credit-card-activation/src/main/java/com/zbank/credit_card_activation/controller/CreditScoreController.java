package com.zbank.credit_card_activation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.zbank.credit_card_activation.model.CreditScore;
import com.zbank.credit_card_activation.repository.CreditScoreRepository;

@RestController
@RequestMapping("/api/creditscore")
public class CreditScoreController {

    @Autowired
    private CreditScoreRepository creditScoreRepository;

    @PostMapping("/add")
    public ResponseEntity<CreditScore> addCreditScore(@RequestBody CreditScore creditScore) {
        CreditScore savedCreditScore = creditScoreRepository.save(creditScore);
        return ResponseEntity.ok(savedCreditScore);
    }
}
