package com.zbank.credit_card_activation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditCardActivationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditCardActivationApplication.class, args);
	}

}
