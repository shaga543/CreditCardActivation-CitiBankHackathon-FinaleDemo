package com.zbank.credit_card_activation.model;
import javax.validation.constraints.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "CardDetails")
public class CardDetails {
    @Id
    @NotBlank(message = "Card ID is mandatory")
    private String cardId;
    
    @NotBlank(message = "User ID is mandatory")
    private String userId;
    
    @NotBlank(message = "Card type is mandatory")
    private String cardType;
    
    @Min(value = 0, message = "Credit limit must be greater than or equal to 0")
    private int creditLimit;
    
    @NotNull(message = "Card number is mandatory")
    private long cardNumber;
    
    @Size(min = 4, max = 4, message = "PIN must be exactly 4 characters")
    private String pin;
    
    
    private LocalDateTime issueDate;

    
    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(int creditLimit) {
        this.creditLimit = creditLimit;
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public LocalDateTime getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDateTime issueDate) {
        this.issueDate = issueDate;
    }
}
