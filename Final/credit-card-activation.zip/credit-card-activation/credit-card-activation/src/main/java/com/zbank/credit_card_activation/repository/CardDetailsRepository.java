package com.zbank.credit_card_activation.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.zbank.credit_card_activation.model.CardDetails;


public interface CardDetailsRepository extends MongoRepository<CardDetails, String> {
}

