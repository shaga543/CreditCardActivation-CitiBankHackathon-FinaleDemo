package com.zbank.credit_card_activation.exception;



public class InvalidCreditScoreException extends RuntimeException {
    public InvalidCreditScoreException(String message) {
        super(message);
    }
}

