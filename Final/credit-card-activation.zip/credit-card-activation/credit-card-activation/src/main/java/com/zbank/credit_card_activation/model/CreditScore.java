package com.zbank.credit_card_activation.model;

import org.springframework.data.annotation.Id;
import javax.validation.constraints.*;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CreditScore")
public class CreditScore {
    @Id
    @NotBlank(message = "Credit score ID is mandatory")
    private String creditscoreId;
    
    @Min(value = 0, message = "Credit score must be greater than or equal to 0")
    @Max(value = 850, message = "Credit score must be less than or equal to 850")
    private int creditscore;
    
    @NotBlank(message = "User ID is mandatory")
    private String userId;

    // 
    public String getCreditscoreId() {
        return creditscoreId;
    }

    public void setCreditscoreId(String creditscoreId) {
        this.creditscoreId = creditscoreId;
    }

    public int getCreditscore() {
        return creditscore;
    }

    public void setCreditscore(int creditscore) {
        this.creditscore = creditscore;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}

