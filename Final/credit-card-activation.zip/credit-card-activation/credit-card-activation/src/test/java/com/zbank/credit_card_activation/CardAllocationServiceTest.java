package com.zbank.credit_card_activation;

import com.zbank.credit_card_activation.model.CardDetails;
import com.zbank.credit_card_activation.model.CreditScore;
import com.zbank.credit_card_activation.repository.CardDetailsRepository;
import com.zbank.credit_card_activation.repository.CreditScoreRepository;
import com.zbank.credit_card_activation.service.CardAllocationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class CardAllocationServiceTest {

    @Autowired
    private CardAllocationService cardAllocationService;

    @MockBean
    private CreditScoreRepository creditScoreRepository;

    @MockBean
    private CardDetailsRepository cardDetailsRepository;

    @Test
    void testAllocateCard_Success() {
        
        String userId = "user9";
        
        CreditScore creditScore = new CreditScore();
        creditScore.setUserId(userId);
        creditScore.setCreditscore(600); 

        CardDetails cardDetails = new CardDetails();
        cardDetails.setUserId(userId);
        cardDetails.setCardType("PLATINUM");
        cardDetails.setCreditLimit(40000);

        
        when(creditScoreRepository.findByUserId(userId)).thenReturn(creditScore);
        when(cardDetailsRepository.save(any(CardDetails.class))).thenReturn(cardDetails);

        
        CardDetails result = cardAllocationService.allocateCard(userId);

        
        assertEquals(userId, result.getUserId());
        assertEquals("PLATINUM", result.getCardType());
        assertEquals(40000, result.getCreditLimit());
    }
}
